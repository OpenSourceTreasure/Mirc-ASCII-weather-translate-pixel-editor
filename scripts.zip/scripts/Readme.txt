Pixel Editor - by Dazuz @ QuakeNet


DEPENDENCIES

mIRC 	7.61+


INSTALLATION

//load -rs $qt($findfile($mircdir,Pixel Editor.mrc,1))


UNINSTALLATION

//unload -rs $qt($script(Pixel Editor.mrc))


USAGE

/pe
